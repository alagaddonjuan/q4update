document.addEventListener('DOMContentLoaded', () => {
    const token = localStorage.getItem('authToken');
    if (!token) {
        window.location.href = '/login.html';
        return;
    }

    let globalData = {};

    // --- Template-specific elements ---
    const mainContentContainer = document.querySelector('#content .container-fluid');
    const userNameSpan = document.getElementById('user-name-display');
    const logoutButton = document.getElementById('logout-link');
    
    
    // --- Navigation Links ---
    const navDashboard = document.getElementById('nav-dashboard-link');
    const navServices = document.getElementById('nav-services-link');
    const navUssd = document.getElementById('nav-ussd-link');
    const navBilling = document.getElementById('nav-billing-link');
    const navProfile = document.getElementById('top-bar-profile-link');
    const navMenuBuilder = document.getElementById('nav-menu-builder-link');
    

    // --- Core Data Fetching ---
    async function fetchAllData() {
        try {
            const response = await fetch('/api/dashboard', { headers: { 'Authorization': `Bearer ${token}` } });
            if (!response.ok) throw new Error('Session expired');
            globalData = await response.json();
            
            if (userNameSpan && globalData.client) {
                userNameSpan.textContent = globalData.client.name;
            }
            renderDashboardView(); 
        } catch (error) {
            localStorage.removeItem('authToken');
            window.location.href = '/login.html';
        }
    }

    // --- RENDER FUNCTIONS FOR EACH VIEW ---

    function renderDashboardView() {
        if (!globalData.client || !globalData.stats) return;
        const balance = globalData.client.token_balance;
        const stats = globalData.stats;
        const apiKey = globalData.client.api_key;
        const maskApiKey = (key) => '*'.repeat(key.length - 8) + key.slice(-8);

        mainContentContainer.innerHTML = `
            <div class="d-sm-flex align-items-center justify-content-between mb-4"><h1 class="h3 mb-0 text-gray-800">Dashboard</h1></div>
            <div class="row">
                <div class="col-xl-3 col-md-6 mb-4"><div class="card border-left-primary shadow h-100 py-2"><div class="card-body"><div class="row no-gutters align-items-center"><div class="col mr-2"><div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Token Balance</div><div class="h5 mb-0 font-weight-bold text-gray-800">${balance} Tokens</div></div><div class="col-auto"><i class="fas fa-coins fa-2x text-gray-300"></i></div></div></div></div></div>
                <div class="col-xl-3 col-md-6 mb-4"><div class="card border-left-success shadow h-100 py-2"><div class="card-body"><div class="row no-gutters align-items-center"><div class="col mr-2"><div class="text-xs font-weight-bold text-success text-uppercase mb-1">Total SMS Sent</div><div class="h5 mb-0 font-weight-bold text-gray-800">${stats.totalSmsSent}</div></div><div class="col-auto"><i class="fas fa-comments fa-2x text-gray-300"></i></div></div></div></div></div>
                <div class="col-xl-3 col-md-6 mb-4"><div class="card border-left-info shadow h-100 py-2"><div class="card-body"><div class="row no-gutters align-items-center"><div class="col mr-2"><div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Airtime Sent</div><div class="h5 mb-0 font-weight-bold text-gray-800">${stats.totalAirtimeSent}</div></div><div class="col-auto"><i class="fas fa-mobile-alt fa-2x text-gray-300"></i></div></div></div></div></div>
                <div class="col-xl-3 col-md-6 mb-4"><div class="card border-left-warning shadow h-100 py-2"><div class="card-body"><div class="row no-gutters align-items-center"><div class="col mr-2"><div class="text-xs font-weight-bold text-warning text-uppercase mb-1">USSD Tokens Used</div><div class="h5 mb-0 font-weight-bold text-gray-800">${stats.totalUssdTokensSpent}</div></div><div class="col-auto"><i class="fas fa-hashtag fa-2x text-gray-300"></i></div></div></div></div></div>
            </div>
            <div class="card shadow mb-4">
                <div class="card-header py-3"><h6 class="m-0 font-weight-bold text-primary">Your API Key</h6></div>
                <div class="card-body">
                    <p>Use this key to integrate with your applications.</p>
                    <pre><code id="api-key-display">${maskApiKey(apiKey)}</code></pre>
                    <div role="group">
                        <button id="toggle-key-btn" class="btn btn-sm btn-secondary">Show</button>
                        <button id="copy-key-btn" class="btn btn-sm btn-secondary">Copy</button>
                    </div>
                </div>
            </div>
        `;

        const toggleBtn = document.getElementById('toggle-key-btn');
        const copyBtn = document.getElementById('copy-key-btn');
        const keyDisplay = document.getElementById('api-key-display');

        toggleBtn.addEventListener('click', () => {
            if (keyDisplay.textContent === maskApiKey(apiKey)) {
                keyDisplay.textContent = apiKey;
                toggleBtn.textContent = 'Hide';
            } else {
                keyDisplay.textContent = maskApiKey(apiKey);
                toggleBtn.textContent = 'Show';
            }
        });
        copyBtn.addEventListener('click', () => {
            navigator.clipboard.writeText(apiKey).then(() => {
                copyBtn.textContent = 'Copied!';
                setTimeout(() => { copyBtn.textContent = 'Copy'; }, 2000);
            });
        });
    }

    mainContentContainer.addEventListener('click', (event) => {
    if (event.target.matches('.set-active-btn')) {
        const menuId = event.target.dataset.menuId;
        handleSetActiveMenu(menuId);
    }
    // We'll add the edit button handler here later
});

    function renderServicesView() {
        mainContentContainer.innerHTML = `
            <h1 class="h3 mb-2 text-gray-800">Services</h1>
            <div class="row">
                <div class="col-lg-6">
                    <div class="card shadow mb-4"><div class="card-header py-3"><h6 class="m-0 font-weight-bold text-primary">Send SMS</h6></div><div class="card-body">
                        <form id="sms-form"><div class="form-group"><label>Recipient Numbers (one per line)</label><textarea id="smsTo" class="form-control" rows="5" required></textarea></div><div class="form-group"><label>Message</label><textarea id="smsMessage" class="form-control" rows="3" required></textarea></div><button type="submit" class="btn btn-primary">Send SMS</button></form>
                    </div></div>
                </div>
                <div class="col-lg-6">
                     <div class="card shadow mb-4"><div class="card-header py-3"><h6 class="m-0 font-weight-bold text-primary">Send Airtime</h6></div><div class="card-body">
                        <form id="airtime-form"><div class="form-group"><label>Phone Number</label><input type="text" id="airtimeTo" class="form-control" required></div><div class="form-group"><label>Amount (NGN)</label><input type="number" id="airtimeAmount" class="form-control" required></div><button type="submit" class="btn btn-primary">Send Airtime</button></form>
                     </div></div>
                </div>
            </div>
            <div class="card shadow mb-4"><div class="card-header py-3"><h6 class="m-0 font-weight-bold text-primary">Usage Logs</h6></div><div class="card-body">
                <h5>SMS Logs</h5><div class="table-responsive"><table class="table table-bordered" id="sms-usage-table"><thead><tr><th>Date</th><th>Status</th><th>Cost</th></tr></thead><tbody></tbody></table></div>
                <h5 class="mt-4">Airtime Logs</h5><div class="table-responsive"><table class="table table-bordered" id="airtime-usage-table"><thead><tr><th>Date</th><th>Phone Number</th><th>Amount</th><th>Status</th></tr></thead><tbody></tbody></table></div>
            </div></div>`;
        initializeServicesView();
    }

    function renderUssdView() {
        const ussdCode = globalData.client?.ussd_code || "None Assigned";
        mainContentContainer.innerHTML = `
            <h1 class="h3 mb-2 text-gray-800">USSD Service</h1>
            <div class="card shadow mb-4"><div class="card-header py-3"><h6 class="m-0 font-weight-bold text-primary">Your Assigned USSD Code</h6></div><div class="card-body"><p>Your active USSD code is: <strong>${ussdCode}</strong></p></div></div>
            <div class="card shadow mb-4"><div class="card-header py-3"><h6 class="m-0 font-weight-bold text-primary">USSD Usage Logs</h6></div><div class="card-body"><div class="table-responsive"><table class="table table-bordered" id="ussd-usage-table">
                <thead><tr><th>Date</th><th>Phone Number</th><th>Final Input</th><th>Status</th><th>Cost (Tokens)</th></tr></thead><tbody></tbody>
            </table></div></div></div>`;
        initializeUssdView();
    }

    function renderBillingView() {
        mainContentContainer.innerHTML = `
            <h1 class="h3 mb-2 text-gray-800">Billing & Top-Up</h1>
            <div class="row">
                <div class="col-lg-6"><div class="card shadow mb-4"><div class="card-header py-3"><h6 class="m-0 font-weight-bold text-primary">Buy Tokens</h6></div><div class="card-body">
                    <form id="buy-tokens-form">
                        <div class="form-group"><label>Amount (NGN)</label><input type="number" id="amount" class="form-control" placeholder="1000" required min="100"></div>
                        <div role="group">
                            <button type="button" id="paystack-btn" class="btn btn-primary">Pay with Paystack</button>
                            <button type="button" id="squad-btn" class="btn btn-secondary">Pay with Q4 Payment</button>
                        </div>
                    </form>
                </div></div></div>
                <div class="col-lg-6"><div class="card shadow mb-4"><div class="card-header py-3"><h6 class="m-0 font-weight-bold text-primary">Conversion Rate</h6></div><div class="card-body"><p>Your price is currently <strong>1 Token</strong> for every <strong>₦1.00</strong>.</p><p><em>Example: ₦1000 = 1000 Tokens</em></p></div></div></div>
            </div>
            <div class="card shadow mb-4"><div class="card-header py-3"><h6 class="m-0 font-weight-bold text-primary">Your Transaction History</h6></div><div class="card-body"><div class="table-responsive"><table class="table table-bordered" id="transactions-table">
                <thead><tr><th>Date</th><th>Reference</th><th>Amount (NGN)</th><th>Tokens</th><th>Status</th></tr></thead><tbody></tbody>
            </table></div></div></div>`;
        initializeBillingView();
    }

    function renderProfileView() {
        mainContentContainer.innerHTML = `
            <h1 class="h3 mb-2 text-gray-800">Your Profile</h1>
            <div class="row">
                <div class="col-lg-6"><div class="card shadow mb-4"><div class="card-header py-3"><h6 class="m-0 font-weight-bold text-primary">Update Information</h6></div><div class="card-body">
                    <form id="profile-form"><div class="form-group"><label>Company Name</label><input type="text" id="profile-name" class="form-control" required></div><button type="submit" class="btn btn-primary">Update Name</button></form>
                </div></div></div>
                <div class="col-lg-6"><div class="card shadow mb-4"><div class="card-header py-3"><h6 class="m-0 font-weight-bold text-primary">Change Password</h6></div><div class="card-body">
                    <form id="password-form"><div class="form-group"><label>New Password</label><input type="password" id="profile-password" class="form-control" required></div><div class="form-group"><label>Confirm New Password</label><input type="password" id="profile-confirm-password" class="form-control" required></div><button type="submit" class="btn btn-primary">Change Password</button></form>
                </div></div></div>
            </div>
            <hr>
            <div class="card shadow mb-4"><div class="card-header py-3"><h6 class="m-0 font-weight-bold text-primary">Two-Factor Authentication (2FA)</h6></div>
                <div class="card-body" id="2fa-section"></div>
            </div>`;
        initializeProfileView();
    }
    
    function renderMenuBuilderView() {
    mainContentContainer.innerHTML = `
        <h1 class="h3 mb-2 text-gray-800">USSD Menu Builder</h1>
        <p class="mb-4">Here you can create and manage your USSD menus.</p>
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Your Menus</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="menus-table">
                        <thead>
                            <tr>
                                <th>Menu Name</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            </tbody>
                    </table>
                </div>
            </div>
        </div>
    `;
    populateMenusTable(); // We'll create this function next
}

    // --- Initializers for each view ---
    function initializeServicesView() {
        document.getElementById('sms-form').addEventListener('submit', handleSmsSubmit);
        document.getElementById('airtime-form').addEventListener('submit', handleAirtimeSubmit);
        populateSmsLogs();
        populateAirtimeLogs();
    }

    function initializeUssdView() {
        populateUssdLogs();
    }

    function initializeBillingView() {
        document.getElementById('paystack-btn').addEventListener('click', handlePaymentInit);
        document.getElementById('squad-btn').addEventListener('click', handleSquadInit);
        populateTransactionsTable();
    }
    
    function initializeProfileView() {
        document.getElementById('profile-name').value = globalData.client.name;
        document.getElementById('profile-form').addEventListener('submit', handleProfileUpdate);
        document.getElementById('password-form').addEventListener('submit', handlePasswordUpdate);
        render2FASection();
    }
    
    function render2FASection() {
        const container = document.getElementById('2fa-section');
        if (globalData.client.is_2fa_enabled) {
            container.innerHTML = `<p class="text-success">Two-Factor Authentication is currently enabled on your account.</p>`;
        } else {
            container.innerHTML = `
                <p>Add an extra layer of security to your account by enabling 2FA.</p>
                <button id="enable-2fa-btn" class="btn btn-primary">Enable 2FA</button>
                <div id="qr-code-container" style="display:none; margin-top: 1rem;">
                    <p>1. Scan this QR code with your authenticator app (e.g., Google Authenticator).</p>
                    <canvas id="qr-code-canvas"></canvas>
                    <p class="mt-3">2. Enter the 6-digit code from your app to verify and complete setup.</p>
                    <form id="verify-2fa-form" class="form-inline">
                        <input type="text" id="2fa-token" class="form-control mb-2 mr-sm-2" placeholder="123456" required pattern="[0-9]{6}" title="Enter a 6-digit code">
                        <button type="submit" class="btn btn-success mb-2">Verify & Activate</button>
                    </form>
                </div>`;
            document.getElementById('enable-2fa-btn').addEventListener('click', handle2FAGenerate);
        }
    }

    // --- Handlers & Populators ---
    async function handle2FAGenerate() {
        try {
            const response = await fetch('/api/2fa/generate', { method: 'POST', headers: { 'Authorization': `Bearer ${token}` } });
            if (!response.ok) throw new Error('Could not start 2FA setup.');
            const data = await response.json();
            document.getElementById('qr-code-container').style.display = 'block';
            document.getElementById('enable-2fa-btn').style.display = 'none';
            const canvas = document.getElementById('qr-code-canvas');
            QRCode.toCanvas(canvas, data.otpauth_url, function (error) { if (error) console.error(error); });
            document.getElementById('verify-2fa-form').addEventListener('submit', handle2FAVerify);
        } catch (error) { alert('Error: ' + error.message); }
    }

    async function handle2FAVerify(event) {
        event.preventDefault();
        const token2FA = document.getElementById('2fa-token').value;
        try {
            const response = await fetch('/api/2fa/verify', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` }, body: JSON.stringify({ token: token2FA }) });
            const result = await response.json();
            if (!response.ok) throw new Error(result.error);
            alert('2FA has been enabled successfully!');
            await fetchAllData();
            renderProfileView();
        } catch (error) { alert('Error: ' + error.message); }
    }
    
    async function handleSmsSubmit(event) {
        event.preventDefault();
        const form = event.target;
        const to = document.getElementById('smsTo').value;
        const message = document.getElementById('smsMessage').value;
        try {
            const response = await fetch('/api/sendsms', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` }, body: JSON.stringify({ to, message }) });
            const result = await response.json();
            if (!response.ok) throw new Error(result.error || 'Failed to send SMS');
            alert('SMS sent successfully!');
            form.reset();
            fetchAllData().then(populateSmsLogs);
        } catch (error) { alert(`Error: ${error.message}`); }
    }

    async function handleAirtimeSubmit(event) {
        event.preventDefault();
        const form = event.target;
        const phoneNumber = document.getElementById('airtimeTo').value;
        const amount = document.getElementById('airtimeAmount').value;
        try {
            const response = await fetch('/api/sendairtime', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` }, body: JSON.stringify({ phoneNumber, amount }) });
            const result = await response.json();
            if (!response.ok) throw new Error(result.error || 'Failed to send Airtime');
            alert('Airtime sent successfully!');
            form.reset();
            fetchAllData().then(populateAirtimeLogs);
        } catch (error) { alert(`Error: ${error.message}`); }
    }

    async function handlePaymentInit() {
        const amount = document.getElementById('amount').value;
        try {
            const response = await fetch('/api/billing/initialize', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` }, body: JSON.stringify({ amount }) });
            const result = await response.json();
            if (!response.ok) throw new Error(result.error);
            window.location.href = result.authorization_url;
        } catch (error) { alert(`Error: ${error.message}`); }
    }

    async function handleSquadInit() {
        if (typeof Squad === 'undefined') { return alert('Payment gateway is still loading. Please try again in a moment.'); }
        const amount = document.getElementById('amount').value;
        try {
            const response = await fetch('/api/billing/squad/initialize', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` }, body: JSON.stringify({ amount }) });
            const data = await response.json();
            if (!response.ok) throw new Error(data.error);
            const squad = new Squad({
                onClose: () => console.log("Widget closed."),
                onSuccess: () => { alert('Payment successful! Your account will be credited shortly.'); window.location.reload(); },
                key: data.publicKey, email: data.email, amount: data.amount,currency_code: 'NGN', transaction_ref: data.reference,
                customer_name: globalData.client.name,
            });
            squad.setup();
            squad.open();
        } catch (error) { alert(`Error: ${error.message}`); }
    }

    async function handleProfileUpdate(event) {
        event.preventDefault();
        const name = document.getElementById('profile-name').value;
        try {
            const response = await fetch('/api/profile', { method: 'PUT', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` }, body: JSON.stringify({ name }) });
            const result = await response.json();
            if (!response.ok) throw new Error(result.error);
            alert('Name updated successfully!');
            fetchAllData();
        } catch (error) { alert(`Error: ${error.message}`); }
    }

    async function handlePasswordUpdate(event) {
        event.preventDefault();
        const password = document.getElementById('profile-password').value;
        const confirmPassword = document.getElementById('profile-confirm-password').value;
        if (password !== confirmPassword) { return alert('Passwords do not match.'); }
        try {
            const response = await fetch('/api/profile', { method: 'PUT', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` }, body: JSON.stringify({ password }) });
            const result = await response.json();
            if (!response.ok) throw new Error(result.error);
            alert('Password changed successfully!');
            event.target.reset();
        } catch (error) { alert(`Error: ${error.message}`); }
    }

    function populateSmsLogs() {
        const tableBody = document.querySelector('#sms-usage-table tbody');
        tableBody.innerHTML = '';
        if (!globalData.sms_logs || globalData.sms_logs.length === 0) { tableBody.innerHTML = '<tr><td colspan="3">No SMS usage found.</td></tr>'; return; }
        globalData.sms_logs.forEach(log => { tableBody.innerHTML += `<tr><td>${new Date(log.logged_at).toLocaleString()}</td><td>${log.status}</td><td>${log.cost}</td></tr>`; });
    }

    function populateAirtimeLogs() {
        const tableBody = document.querySelector('#airtime-usage-table tbody');
        tableBody.innerHTML = '';
        if (!globalData.airtime_logs || globalData.airtime_logs.length === 0) { tableBody.innerHTML = '<tr><td colspan="4">No Airtime usage found.</td></tr>'; return; }
        globalData.airtime_logs.forEach(log => { tableBody.innerHTML += `<tr><td>${new Date(log.logged_at).toLocaleString()}</td><td>${log.phone_number}</td><td>${log.amount}</td><td>${log.status}</td></tr>`; });
    }

    function populateUssdLogs() {
        const tableBody = document.querySelector('#ussd-usage-table tbody');
        tableBody.innerHTML = '';
        if (!globalData.ussd_logs || globalData.ussd_logs.length === 0) { tableBody.innerHTML = '<tr><td colspan="5">No USSD usage found.</td></tr>'; return; }
        globalData.ussd_logs.forEach(log => { tableBody.innerHTML += `<tr><td>${new Date(log.logged_at).toLocaleString()}</td><td>${log.phone_number}</td><td>${log.final_user_string || '-'}</td><td>${log.status}</td><td>${log.client_price || 0} Tokens</td></tr>`; });
    }

    function populateTransactionsTable() {
        const tableBody = document.querySelector('#transactions-table tbody');
        tableBody.innerHTML = '';
        if (!globalData.transactions || globalData.transactions.length === 0) { tableBody.innerHTML = '<tr><td colspan="5">No transactions found.</td></tr>'; return; }
        globalData.transactions.forEach(tx => { tableBody.innerHTML += `<tr><td>${new Date(tx.created_at).toLocaleString()}</td><td>${tx.reference}</td><td>₦${parseFloat(tx.amount).toFixed(2)}</td><td>${tx.tokens_purchased}</td><td>${tx.status}</td></tr>`; });
    }
    
    function populateMenusTable() {
    const tableBody = document.querySelector('#menus-table tbody');
    try {
        fetch('/api/ussd/menus', { headers: { 'Authorization': `Bearer ${token}` } })
            .then(response => {
                if (!response.ok) throw new Error('Could not fetch menus.');
                return response.json();
            })
            .then(menus => {
                tableBody.innerHTML = ''; // Clear previous content
                if (menus.length === 0) {
                    tableBody.innerHTML = '<tr><td colspan="3">You have not created any menus yet.</td></tr>';
                } else {
                    menus.forEach(menu => {
                        tableBody.innerHTML += `
                            <tr>
                                <td>${menu.menu_name}</td>
                                <td>${menu.is_active ? '<span class="text-success">Active</span>' : 'Inactive'}</td>
                                <td>
                                    <a href="/edit-menu.html?id=${menu.id}" class="btn btn-sm btn-info">Edit</a>
                                    
                                    <button class="btn btn-sm btn-success set-active-btn" data-menu-id="${menu.id}">Set Active</button>
                                </td>
                            </tr>
                        `;
                    });
                }
            });
    } catch (error) {
        tableBody.innerHTML = `<tr><td colspan="3">Error loading menus: ${error.message}</td></tr>`;
    }
}

    async function handleSetActiveMenu(menuId) {
    try {
        const response = await fetch('/api/ussd/menus/set-active', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ menuId: menuId })
        });

        const result = await response.json();
        if (!response.ok) throw new Error(result.error);

        alert(result.message);
        renderMenuBuilderView(); // Re-render the view to show the change
    } catch (error) {
        alert('Error: ' + error.message);
    }
}

    // --- EVENT LISTENERS for navigation ---
    logoutButton.addEventListener('click', (e) => { e.preventDefault(); localStorage.removeItem('authToken'); window.location.href = '/login.html'; });
    navDashboard.addEventListener('click', (e) => { e.preventDefault(); renderDashboardView(); });
    navServices.addEventListener('click', (e) => { e.preventDefault(); renderServicesView(); });
    navUssd.addEventListener('click', (e) => { e.preventDefault(); renderUssdView(); });
    navBilling.addEventListener('click', (e) => { e.preventDefault(); renderBillingView(); });
    navProfile.addEventListener('click', (e) => { e.preventDefault(); renderProfileView(); });
    navMenuBuilder.addEventListener('click', (e) => {e.preventDefault();
    renderMenuBuilderView();
});
    
    // --- Initial Load ---
    fetchAllData();
});
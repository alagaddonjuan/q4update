document.addEventListener('DOMContentLoaded', () => {
    const token = localStorage.getItem('authToken');
    if (!token) {
        window.location.href = '/login.html'; // Redirect if not logged in
        return;
    }

    const menuNameHeader = document.getElementById('menu-name-header');
    const itemsContainer = document.getElementById('menu-items-container');
    const addItemForm = document.getElementById('add-item-form');
    const parentItemIdInput = document.getElementById('parent-item-id');

    // Get menu ID from the URL query parameter
    const urlParams = new URLSearchParams(window.location.search);
    const menuId = urlParams.get('id');

    if (!menuId) {
        menuNameHeader.textContent = "Error: No Menu ID Provided";
        return;
    }

    // --- DATA FETCHING AND RENDERING ---
    
    async function fetchAndRenderMenu() {
        try {
            const response = await fetch(`/api/ussd/menus/${menuId}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (!response.ok) throw new Error('Could not load menu data.');
            
            const { menu, items } = await response.json();
            menuNameHeader.textContent = `Editing: ${menu.menu_name}`;
            
            renderMenuItems(items);

        } catch (error) {
            itemsContainer.innerHTML = `<p class="text-danger">${error.message}</p>`;
        }
    }

    function renderMenuItems(items, parentId = null, level = 0) {
        const children = items.filter(item => item.parent_item_id === parentId);
        if (children.length === 0 && level === 0) {
            itemsContainer.innerHTML = '<p>No menu items yet. Add a ROOT item to start.</p>';
            return;
        }

        const ul = document.createElement('ul');
        ul.style.marginLeft = `${level * 20}px`;
        ul.style.listStyle = 'none';

        children.forEach(item => {
            const li = document.createElement('li');
            li.innerHTML = `
                <strong>Trigger: ${item.option_trigger}</strong> (${item.response_type})
                <p><em>${item.response_text.replace(/\n/g, '<br>')}</em></p>
                `;
            ul.appendChild(li);

            // Recursively render children
            const childHtml = renderMenuItems(items, item.id, level + 1);
            if(childHtml) {
                li.appendChild(childHtml);
            }
        });
        
        if (level === 0) {
            itemsContainer.innerHTML = '';
            itemsContainer.appendChild(ul);
        } else {
            return ul;
        }
    }
    
    // --- FORM HANDLING ---

    addItemForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        
        const formData = {
            parent_item_id: parentItemIdInput.value || null,
            option_trigger: document.getElementById('option-trigger').value,
            response_type: document.getElementById('response-type').value,
            response_text: document.getElementById('response-text').value,
        };

        try {
            const response = await fetch(`/api/ussd/menus/${menuId}/items`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(formData)
            });
            const result = await response.json();
            if (!response.ok) throw new Error(result.error);

            alert(result.message);
            addItemForm.reset();
            fetchAndRenderMenu(); // Refresh the menu view
        } catch (error) {
            alert('Error: ' + error.message);
        }
    });

    // --- INITIAL LOAD ---
    fetchAndRenderMenu();
});
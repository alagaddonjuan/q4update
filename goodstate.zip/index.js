require('dotenv').config();
const express = require('express');
const { knex, setupDatabase } = require('./database');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const path = require('path');
const paystack = require('paystack-api')(process.env.PAYSTACK_SECRET_KEY);
const nodemailer = require('nodemailer');
const speakeasy = require('speakeasy');

const createResetEmailTemplate = (resetUrl, logoUrl) => {
    return `<!DOCTYPE html><html><head><style>body{font-family:Arial,sans-serif;line-height:1.6;color:#333}.container{width:100%;max-width:600px;margin:20px auto;padding:20px;border:1px solid #ddd;border-radius:5px}.header{text-align:center;margin-bottom:20px}.button{display:inline-block;padding:12px 24px;background-color:#007bff;color:#fff;text-decoration:none;border-radius:5px}.footer{margin-top:20px;font-size:.8em;text-align:center;color:#777}</style></head><body><div class="container"><div class="header"><img src="${logoUrl}" alt="Your Company Logo" style="width:150px"></div><h2>Password Reset Request</h2><p>You requested a password reset. Click the button below to set a new password. This link is valid for one hour.</p><p style="text-align:center"><a href="${resetUrl}" class="button">Reset Your Password</a></p><p>If you did not request a password reset, please ignore this email.</p><div class="footer"><p>&copy; ${new Date().getFullYear()} Your Company. All rights reserved.</p></div></div></body></html>`;
};

// --- Define Token Costs & SDK ---
const NGN_TO_TOKEN_RATE = 1;
const SMS_TOKEN_COST = 10;
const USSD_INTERVAL_TOKEN_COST = 20;
const options = { apiKey: process.env.AT_API_KEY, username: process.env.AT_USERNAME };
const africastalking = require('africastalking')(options);

setupDatabase();

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

const PORT = process.env.PORT || 3000;

// --- MIDDLEWARE ---
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (token == null) return res.sendStatus(401);
    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
};

const isAdmin = (req, res, next) => {
    if (req.user && req.user.isAdmin) {
        next();
    } else {
        res.status(403).json({ error: 'Forbidden: Requires admin access.' });
    }
};

// --- ROUTES ---
app.get('/', (req, res) => { res.sendFile(path.join(__dirname, 'public', 'index.html')); });

// --- AUTHENTICATION ROUTES ---
app.post('/auth/register', async (req, res) => {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
        return res.status(400).json({ error: 'Name, email, and password are required.' });
    }
    try {
        const userCountResult = await knex('clients').count('id as count').first();
        const userCount = userCountResult ? userCountResult.count : 0;
        const isAdmin = userCount === 0;
        const hashedPassword = await bcrypt.hash(password, 10);
        const apiKey = crypto.randomBytes(16).toString('hex');
        const newClient = { name, email, password: hashedPassword, api_key: apiKey, is_admin: isAdmin };
        const [insertedClient] = await knex('clients').insert(newClient).returning(['id', 'name', 'email']);
        console.log(`New client registered: ${insertedClient.name}${isAdmin ? ' (as ADMIN)' : ''}`);
        res.status(201).json({ message: 'Registration successful!', client: insertedClient });
    } catch (error) {
        if (error.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({ error: 'A user with this email already exists.' });
        }
        console.error('Registration error:', error);
        res.status(500).json({ error: 'An error occurred during registration.' });
    }
});

app.post('/auth/login', async (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password are required.' });
    try {
        const client = await knex('clients').where({ email }).first();
        if (!client || !(await bcrypt.compare(password, client.password))) {
            return res.status(401).json({ error: 'Invalid credentials.' });
        }
        if (client.is_2fa_enabled) {
            const tempToken = jwt.sign({ id: client.id, name: client.name, two_factor_authenticated: false }, process.env.JWT_SECRET, { expiresIn: '5m' });
            return res.status(200).json({ two_factor_required: true, temp_token: tempToken });
        }
        const token = jwt.sign({ id: client.id, name: client.name, isAdmin: client.is_admin, two_factor_authenticated: true }, process.env.JWT_SECRET, { expiresIn: '1h' });
        res.status(200).json({ message: 'Login successful!', token, isAdmin: client.is_admin });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ error: 'An internal server error occurred.' });
    }
});

app.post('/auth/2fa/verify-login', authenticateToken, async (req, res) => {
    const { token: twoFaToken } = req.body;
    const clientId = req.user.id;
    if (!twoFaToken) return res.status(400).json({ error: '2FA token is required.' });
    try {
        const client = await knex('clients').where({ id: clientId }).first();
        const isVerified = speakeasy.totp.verify({
            secret: client.two_fa_secret,
            encoding: 'base32',
            token: twoFaToken,
            window: 1
        });
        if (isVerified) {
            const finalToken = jwt.sign({ id: client.id, name: client.name, isAdmin: client.is_admin, two_factor_authenticated: true }, process.env.JWT_SECRET, { expiresIn: '1h' });
            res.status(200).json({ message: 'Login successful!', token: finalToken, isAdmin: client.is_admin });
        } else {
            res.status(401).json({ error: 'Invalid 2FA token.' });
        }
    } catch (error) {
        console.error('2FA verify login error:', error);
        res.status(500).json({ error: 'An internal error occurred.' });
    }
});

app.post('/auth/forgot-password', async (req, res) => {
    const { email } = req.body;
    try {
        const client = await knex('clients').where({ email }).first();
        if (!client) {
            return res.status(200).json({ message: 'If a user with that email exists, a password reset link has been sent.' });
        }
        const resetToken = crypto.randomBytes(32).toString('hex');
        const expires = new Date();
        expires.setHours(expires.getHours() + 1);
        await knex('clients').where({ id: client.id }).update({ password_reset_token: resetToken, password_reset_expires: expires });
        const resetUrl = `${process.env.APP_URL}/reset-password.html?token=${resetToken}`;
        const logoUrl = 'https://i.imgur.com/your-image-code.png'; // Your public logo URL
        const transporter = nodemailer.createTransport({
            host: process.env.SMTP_HOST,
            port: process.env.SMTP_PORT,
            secure: true,
            auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
        });
        await transporter.sendMail({
            from: `"Q4I Comms Support" <support@q4globalltd.com>`,
            to: client.email,
            subject: 'Your Password Reset Link',
            html: createResetEmailTemplate(resetUrl, logoUrl)
        });
        res.status(200).json({ message: 'If a user with that email exists, a password reset link has been sent.' });
    } catch (error) {
        console.error('Forgot password error:', error);
        res.status(500).json({ error: 'An internal error occurred.' });
    }
});

app.post('/auth/reset-password', async (req, res) => {
    const { token, password } = req.body;
    if (!token || !password) {
        return res.status(400).json({ error: 'Token and a new password are required.' });
    }
    try {
        const client = await knex('clients').where({ password_reset_token: token }).andWhere('password_reset_expires', '>', new Date()).first();
        if (!client) {
            return res.status(400).json({ error: 'Password reset token is invalid or has expired.' });
        }
        const hashedPassword = await bcrypt.hash(password, 10);
        await knex('clients').where({ id: client.id }).update({
            password: hashedPassword, password_reset_token: null, password_reset_expires: null
        });
        res.status(200).json({ message: 'Your password has been successfully reset. Please log in.' });
    } catch (error) {
        console.error('Reset password error:', error);
        res.status(500).json({ error: 'An internal error occurred.' });
    }
});

// --- CLIENT API ROUTES ---
app.get('/api/dashboard', authenticateToken, async (req, res) => {
    try {
        const clientId = req.user.id;
        const smsCount = await knex('sms_logs').where({ client_id: clientId }).count('id as count').first();
        const airtimeCount = await knex('airtime_logs').where({ client_id: clientId }).count('id as count').first();
        const ussdCostSum = await knex('ussd_logs').where({ client_id: clientId }).sum('client_price as total').first();
        const stats = {
            totalSmsSent: smsCount.count || 0,
            totalAirtimeSent: airtimeCount.count || 0,
            totalUssdTokensSpent: ussdCostSum.total || 0
        };
        const [client, sms_logs, airtime_logs, ussd_logs, transactions] = await Promise.all([
            knex('clients').where({ id: clientId }).first(),
            knex('sms_logs').where({ client_id: clientId }).orderBy('logged_at', 'desc').limit(5),
            knex('airtime_logs').where({ client_id: clientId }).orderBy('logged_at', 'desc').limit(5),
            knex('ussd_logs').where({ client_id: clientId }).orderBy('logged_at', 'desc').limit(5),
            knex('transactions').where({ client_id: clientId }).orderBy('created_at', 'desc').limit(5)
        ]);
        if (!client) return res.status(404).json({ error: 'Client not found.' });
        res.status(200).json({ client, stats, sms_logs, airtime_logs, ussd_logs, transactions });
    } catch (error) {
        console.error('Dashboard data error:', error);
        res.status(500).json({ error: 'An internal server error occurred.' });
    }
});

app.get('/api/ussd/menus', authenticateToken, async (req, res) => {
    const clientId = req.user.id;
    try {
        const menus = await knex('ussd_menus').where({ client_id: clientId });
        res.status(200).json(menus);
    } catch (error) {
        console.error("Error fetching USSD menus:", error);
        res.status(500).json({ error: "Could not fetch USSD menus." });
    }
});

app.put('/api/profile', authenticateToken, async (req, res) => {
    const clientId = req.user.id;
    const { name, password } = req.body;
    if (!name && !password) {
        return res.status(400).json({ error: 'At least a name or password is required.' });
    }
    try {
        const updateData = {};
        if (name) updateData.name = name;
        if (password) updateData.password = await bcrypt.hash(password, 10);
        await knex('clients').where({ id: clientId }).update(updateData);
        res.status(200).json({ message: 'Profile updated successfully.' });
    } catch (error) {
        console.error('Profile update error:', error);
        res.status(500).json({ error: 'An internal server error occurred.' });
    }
});

app.post('/api/ussd/menus/set-active', authenticateToken, async (req, res) => {
    const { menuId } = req.body;
    const clientId = req.user.id;

    try {
        await knex.transaction(async (trx) => {
            // First, set all menus for this client to inactive
            await trx('ussd_menus').where({ client_id: clientId }).update({ is_active: false });

            // Then, set the selected menu to active
            await trx('ussd_menus').where({ id: menuId, client_id: clientId }).update({ is_active: true });
        });
        
        res.status(200).json({ message: 'Menu has been set as active.' });
    } catch (error) {
        console.error("Error setting active menu:", error);
        res.status(500).json({ error: 'Failed to set active menu.' });
    }
});

    // GET all items for a specific menu
app.get('/api/ussd/menus/:id', authenticateToken, async (req, res) => {
    const { id } = req.params;
    const clientId = req.user.id;
    try {
        const menu = await knex('ussd_menus').where({ id, client_id: clientId }).first();
        if (!menu) {
            return res.status(404).json({ error: 'Menu not found.' });
        }
        const items = await knex('ussd_menu_items').where({ menu_id: id }).orderBy('id');
        res.status(200).json({ menu, items });
    } catch (error) {
        res.status(500).json({ error: 'Could not fetch menu details.' });
    }
});

// POST a new item to a menu
app.post('/api/ussd/menus/:id/items', authenticateToken, async (req, res) => {
    const { id: menuId } = req.params;
    const { parent_item_id, option_trigger, response_type, response_text } = req.body;

    try {
        const newItem = {
            menu_id: menuId,
            parent_item_id: parent_item_id || null,
            option_trigger,
            response_type,
            response_text
        };
        await knex('ussd_menu_items').insert(newItem);
        res.status(201).json({ message: 'Menu item added successfully.' });
    } catch (error) {
        console.error("Error adding menu item:", error);
        res.status(500).json({ error: 'Could not add menu item.' });
    }
});

app.post('/api/2fa/generate', authenticateToken, async (req, res) => {
    const clientId = req.user.id;
    try {
        const secret = speakeasy.generateSecret({ name: `Q4I Comms (${req.user.name})` });
        await knex('clients').where({ id: clientId }).update({ two_fa_secret: secret.base32 });
        res.json({ secret: secret.base32, otpauth_url: secret.otpauth_url });
    } catch (error) {
        console.error("2FA generation error:", error);
        res.status(500).json({ error: "Could not generate 2FA secret." });
    }
});

app.post('/api/2fa/verify', authenticateToken, async (req, res) => {
    const { token } = req.body;
    const clientId = req.user.id;
    try {
        const client = await knex('clients').where({ id: clientId }).first();
        const isVerified = speakeasy.totp.verify({
            secret: client.two_fa_secret,
            encoding: 'base32',
            token: token
        });
        if (isVerified) {
            await knex('clients').where({ id: clientId }).update({ is_2fa_enabled: true });
            res.json({ message: '2FA enabled successfully!' });
        } else {
            res.status(400).json({ error: 'Invalid 2FA token. Please try again.' });
        }
    } catch (error) {
        res.status(500).json({ error: 'Could not verify 2FA token.' });
    }
});

app.post('/api/billing/initialize', authenticateToken, async (req, res) => {
    const clientId = req.user.id;
    const { amount } = req.body;
    if (!amount || amount <= 0) {
        return res.status(400).json({ error: 'A valid amount is required.' });
    }
    try {
        const client = await knex('clients').where({ id: clientId }).first();
        const reference = crypto.randomBytes(16).toString('hex');
        const tokensPurchased = Math.floor(amount * NGN_TO_TOKEN_RATE);
        await knex('transactions').insert({
            client_id: clientId, gateway: 'paystack', reference, amount, tokens_purchased: tokensPurchased, status: 'Pending'
        });
        const paystackResponse = await paystack.transaction.initialize({
            email: client.email, amount: amount * 100, reference, currency: 'NGN', callback_url: `${process.env.APP_URL}/dashboard.html`
        });
        res.status(200).json(paystackResponse.data);
    } catch (error) {
        console.error("Payment initialization error:", error);
        res.status(500).json({ error: "Failed to start payment process." });
    }
});

app.post('/api/billing/squad/initialize', authenticateToken, async (req, res) => {
    const clientId = req.user.id;
    const { amount } = req.body;
    if (!amount || amount <= 0) {
        return res.status(400).json({ error: 'A valid amount is required.' });
    }
    try {
        const client = await knex('clients').where({ id: clientId }).first();
        const reference = crypto.randomBytes(16).toString('hex');
        const tokensPurchased = Math.floor(amount * NGN_TO_TOKEN_RATE);
        await knex('transactions').insert({
            client_id: clientId, gateway: 'squad', reference, amount, tokens_purchased: tokensPurchased, status: 'Pending'
        });
        res.status(200).json({
            amount: amount * 100, email: client.email, reference, publicKey: process.env.SQUAD_PUBLIC_KEY, customer_name: client.name
        });
    } catch (error) {
        console.error("Squad payment initialization error:", error);
        res.status(500).json({ error: "Failed to start payment process." });
    }
});

app.post('/api/sendsms', authenticateToken, async (req, res) => {
    const clientId = req.user.id;
    const { to, message } = req.body;
    const recipientList = to.split('\n').map(num => num.trim()).filter(num => num);
    if (recipientList.length === 0) {
        return res.status(400).json({ error: 'Please provide at least one valid recipient number.' });
    }
    try {
        const client = await knex('clients').where({ id: clientId }).first();
        const totalTokenCost = recipientList.length * SMS_TOKEN_COST;
        if (client.token_balance < totalTokenCost) {
            return res.status(402).json({ error: `Insufficient token balance.` });
        }
        if (!client.sender_id) {
            return res.status(400).json({ error: 'No Sender ID has been configured for your account.' });
        }
        const toCommaSeparated = recipientList.join(',');
        const result = await africastalking.SMS.send({ to: toCommaSeparated, message, from: client.sender_id });
        console.log("RAW AT RESPONSE:", JSON.stringify(result, null, 2));
        const successfulRecipients = result.SMSMessageData.Recipients.filter(r => r.messageId && r.messageId.startsWith('ATX'));
        if (successfulRecipients.length > 0) {
            await knex('clients').where({ id: clientId }).decrement('token_balance', totalTokenCost);
            const logs = successfulRecipients.map(recipient => ({
                client_id: clientId, message_id: recipient.messageId, cost: recipient.cost, status: recipient.status
            }));
            await knex('sms_logs').insert(logs);
            console.log(`${successfulRecipients.length} SMS sent and client ${clientId} billed ${totalTokenCost} tokens.`);
        } else {
             return res.status(400).json({ error: 'Message failed to send to all recipients. Please check the recipient number.' });
        }
        res.status(200).json(result);
    } catch (error) {
        console.error('Bulk SMS sending error:', error.message);
        res.status(500).json({ error: 'An internal server error occurred while sending SMS.' });
    }
});

app.post('/api/sendairtime', authenticateToken, async (req, res) => {
    const clientId = req.user.id;
    const { phoneNumber, amount } = req.body;
    if (!phoneNumber || !amount || amount <= 0) {
        return res.status(400).json({ error: 'Valid phoneNumber and a positive amount are required.' });
    }
    try {
        const client = await knex('clients').where({ id: clientId }).first();
        const tokenCost = Math.ceil(amount * NGN_TO_TOKEN_RATE);
        if (client.token_balance < tokenCost) {
            return res.status(402).json({ error: `Insufficient token balance.` });
        }
        const options = { recipients: [{ phoneNumber, currencyCode: 'NGN', amount }] };
        const result = await africastalking.AIRTIME.send(options);
        if (result && result.responses && result.responses.length > 0) {
            const response = result.responses[0];
            if (response.status === 'Sent' || response.status === 'Success') {
                await knex('clients').where({ id: clientId }).decrement('token_balance', tokenCost);
                await knex('airtime_logs').insert({
                    client_id: clientId, phone_number: phoneNumber, amount: `NGN ${amount}`, request_id: response.requestId, status: response.status
                });
                console.log(`Airtime sent and client ${clientId} billed ${tokenCost} tokens.`);
            }
        }
        res.status(200).json(result);
    } catch (error) {
        console.error('Airtime sending error:', error.message);
        res.status(500).json({ error: 'An internal server error occurred.' });
    }
});



// --- WEBHOOK ROUTE ---
app.post('/billing/webhook', async (req, res) => {
    console.log("RAW WEBHOOK DATA:", JSON.stringify(req.body, null, 2));
    const event = req.body;
    let reference = null;
    if (event.event === 'charge.success' && event.data) {
        reference = event.data.reference;
    } else if (event.Event === 'charge.success' && event.Body) {
        reference = event.Body.transaction_ref;
    }
    if (reference) {
        try {
            await knex.transaction(async (trx) => {
                const transaction = await trx('transactions').where({ reference, status: 'Pending' }).first();
                if (transaction) {
                    await trx('transactions').where({ id: transaction.id }).update({ status: 'Success' });
                    await trx('clients').where({ id: transaction.client_id }).increment('token_balance', transaction.tokens_purchased);
                    console.log(`Tokens credited for transaction: ${reference}`);
                }
            });
        } catch (error) {
            console.error("Webhook processing error:", error);
        }
    }
    res.sendStatus(200);
});

app.post('/ussd_callback', async (req, res) => {
    const { sessionId, phoneNumber, text, serviceCode, networkCode } = req.body;
    let response = '';

    try {
        const client = await knex('clients').where({ ussd_code: serviceCode }).first();
        if (!client) return res.send('END This service code is not active.');

        const activeMenu = await knex('ussd_menus').where({ client_id: client.id, is_active: true }).first();
        if (!activeMenu) return res.send('END This service is currently unavailable.');

        if (text === '') {
            // First request of the session
            await knex('ussd_logs').insert({ client_id: client.id, session_id: sessionId, phone_number: phoneNumber, network_code: networkCode, status: 'Pending' });
            
            const rootItem = await knex('ussd_menu_items').where({ menu_id: activeMenu.id, parent_item_id: null }).first();
            response = rootItem ? `${rootItem.response_type} ${rootItem.response_text}` : 'END Menu not configured.';
        } else {
            // Subsequent requests
            const inputs = text.split('*');
            const lastInput = inputs[inputs.length - 1];

            // Find the user's current position in the menu tree
            let currentLevelItemId = (await knex('ussd_menu_items').where({ menu_id: activeMenu.id, parent_item_id: null }).first()).id;

            for (let i = 0; i < inputs.length - 1; i++) {
                const menuItem = await knex('ussd_menu_items')
                    .where({ menu_id: activeMenu.id, parent_item_id: currentLevelItemId, option_trigger: inputs[i] })
                    .first();
                if (menuItem) {
                    currentLevelItemId = menuItem.id;
                } else {
                    currentLevelItemId = -1; // Invalid path
                    break;
                }
            }

            // Find the next menu item based on the last input
            const nextMenuItem = await knex('ussd_menu_items')
                .where({ menu_id: activeMenu.id, parent_item_id: currentLevelItemId, option_trigger: lastInput })
                .first();

            response = nextMenuItem ? `${nextMenuItem.response_type} ${nextMenuItem.response_text}` : 'END Invalid selection.';
            
            if (response.startsWith('END')) {
                await knex('ussd_logs').where({ session_id: sessionId }).update({ final_user_string: text });
            }
        }
        res.set('Content-Type: text/plain').send(response);
    } catch (error) {
        console.error('Dynamic USSD callback error:', error);
        res.send('END An error occurred.');
    }
});

app.post('/ussd_events_callback', async (req, res) => {
    const { sessionId, status, durationInSeconds, cost } = req.body;
    res.status(200).send('Event received.');
    console.log("USSD EVENT NOTIFICATION:", JSON.stringify(req.body, null, 2));

    if ((status !== 'Done' && status !== 'Success') || !sessionId) {
        return;
    }

    try {
        await knex.transaction(async (trx) => {
            const logEntry = await trx('ussd_logs').where({ session_id: sessionId }).first();
            if (!logEntry || logEntry.status === 'Completed') {
                return;
            }

            // --- THE FIX IS HERE ---
            // Ensure durationInSeconds is a valid integer, default to 0 if not
            const duration = parseInt(durationInSeconds, 10) || 0;
            // --- END OF FIX ---

            const pricing = await trx('ussd_pricing').where({ network_code: logEntry.network_code }).first();
            const tokensPerInterval = pricing ? pricing.tokens_per_interval : USSD_INTERVAL_TOKEN_COST;
            const intervals = Math.ceil(duration / 20) || 1;
            const clientTokenCost = intervals * tokensPerInterval;

            await trx('ussd_logs')
                .where({ session_id: sessionId })
                .update({
                    duration_seconds: duration, // Use the cleaned duration variable
                    session_cost: cost,
                    client_price: clientTokenCost,
                    status: 'Completed'
                });

            await trx('clients')
                .where({ id: logEntry.client_id })
                .decrement('token_balance', clientTokenCost);
            
            console.log(`USSD session ${sessionId} BILLED ${clientTokenCost} tokens to client ${logEntry.client_id}.`);
        });
    } catch (error) {
        console.error('Error processing USSD event:', error);
    }
});

// --- ADMIN ROUTES ---
app.get('/api/admin/clients', authenticateToken, isAdmin, async (req, res) => {
    try {
        const clients = await knex('clients').select('id', 'name', 'is_admin', 'created_at', 'token_balance', 'sender_id', 'ussd_code');
        res.status(200).json(clients);
    } catch (error) {
        console.error('Admin fetch clients error:', error);
        res.status(500).json({ error: 'An internal server error occurred.' });
    }
});

app.post('/api/admin/topup', authenticateToken, isAdmin, async (req, res) => {
    const { clientId, amount } = req.body;
    if (!clientId || !amount || amount <= 0) return res.status(400).json({ error: 'Valid clientId and a positive amount are required.' });
    try {
        await knex('clients').where({ id: clientId }).increment('token_balance', amount);
        res.status(200).json({ message: `Successfully topped up client ${clientId} with ${amount} tokens.` });
    } catch (error) {
        res.status(500).json({ error: 'An internal server error occurred.' });
    }
});

app.put('/api/admin/clients/:clientId', authenticateToken, isAdmin, async (req, res) => {
    const { clientId } = req.params;
    const { name, ussd_code, sender_id } = req.body;
    const updateData = {};
    if (name) updateData.name = name;
    if (ussd_code !== undefined) updateData.ussd_code = ussd_code;
    if (sender_id !== undefined) updateData.sender_id = sender_id;
    if (Object.keys(updateData).length === 0) {
        return res.status(400).json({ error: 'At least one field to update is required.' });
    }
    try {
        const updatedCount = await knex('clients').where({ id: clientId }).update(updateData);
        if (updatedCount === 0) return res.status(404).json({ error: 'Client not found.' });
        res.status(200).json({ message: 'Client updated successfully.' });
    } catch (error) {
        if (error.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({ error: 'This USSD code is already assigned to another client.' });
        }
        console.error('Update client error:', error);
        res.status(500).json({ error: 'An internal server error occurred.' });
    }
});

app.get('/api/admin/logs', authenticateToken, isAdmin, async (req, res) => {
    try {
        const [smsLogs, airtimeLogs, ussdLogs, transactions] = await Promise.all([
            knex('sms_logs').join('clients', 'sms_logs.client_id', '=', 'clients.id').select('sms_logs.*', 'clients.name as client_name'),
            knex('airtime_logs').join('clients', 'airtime_logs.client_id', '=', 'clients.id').select('airtime_logs.*', 'clients.name as client_name'),
            knex('ussd_logs').join('clients', 'ussd_logs.client_id', '=', 'clients.id').select('ussd_logs.*', 'clients.name as client_name'),
            knex('transactions').join('clients', 'transactions.client_id', '=', 'clients.id').select('transactions.*', 'clients.name as client_name')
        ]);
        res.status(200).json({ smsLogs, airtimeLogs, ussdLogs, transactions });
    } catch (error) {
        console.error('Admin fetch logs error:', error);
        res.status(500).json({ error: 'An internal server error occurred.' });
    }
});

app.get('/api/admin/stats', authenticateToken, isAdmin, async (req, res) => {
    try {
        const totalClientsResult = await knex('clients').count('id as count').first();
        const totalTokensResult = await knex('transactions').where({ status: 'Success' }).sum('tokens_purchased as total').first();
        const totalSmsResult = await knex('sms_logs').count('id as count').first();
        const stats = {
            clientCount: totalClientsResult.count || 0,
            tokensPurchased: totalTokensResult.total || 0,
            smsSentCount: totalSmsResult.count || 0
        };
        res.status(200).json(stats);
    } catch (error) {
        console.error('Admin fetch stats error:', error);
        res.status(500).json({ error: 'An internal server error occurred.' });
    }
});

// --- Server Start ---
app.listen(PORT, () => console.log(`Server is running on port ${PORT}`));